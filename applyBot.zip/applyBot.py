from utils.ai_utils import *
from utils.application_flow import *
from utils.browser_utils import _safe_click
from utils.browser_utils import *
from utils.logging_utils import *
from utils.memory_utils import *
from utils.question_utils import *
import sys


def main():
    init_log()
    driver = setup_driver()
    driver.get(SEARCH_URL)
    root = driver.current_window_handle
    page = 10
    if(not skip_manual):
        test = input("Press Enter to start processing jobs...")
    while True:
        print(f"Processing jobs on page {page}")
        if random.random() < 0.3:
            explore_page(driver)
        title, company = go_to_job(driver, root)
        
        page += 10
        el = driver.find_element(By.CSS_SELECTOR, '[data-testid="pagination-page-next"]')
        _safe_click(driver, el)
        time.sleep(2)


resume_text = load_resume_text(RESUME_PATH)
mem = load_qa_memory()
if __name__ == "__main__":
    if (len(sys.argv)>1):
        skip_manual = True
    main()
    #application_field("How many years of Jira projects experience do you have?")